Page({
  data: {
    activeCategory: 'all',
    videos: [
      {
        title: '鱼灯历史与文化渊源',
        category: 'theory',
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', 
      },
      {
        title: '传统鱼灯制作工艺详解',
        category: 'practice',
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
      },
      {
        title: '鱼灯艺术特色与美学价值',
        category: 'theory',
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
      },
      {
        title: '现代创新技法与工具使用',
        category: 'practice',
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
      },
      {
        title: '彩绘技法与色彩搭配',
        category: 'practice',
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
      },
      {
        title: '非遗保护与传承现状',
        category: 'theory',
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
      }
    ],
    filteredVideos: []
  },
  onCategoryTap(e) {
    const category = e.currentTarget.dataset.category;
    this.setData({
      activeCategory: category,
      filteredVideos: this.filterVideos(category)
    });
  },
  filterVideos(category) {
    if (category === 'all') return this.data.videos;
    return this.data.videos.filter(v => v.category === category);
  },
  onLoad() {
    this.setData({
      filteredVideos: this.data.videos
    });
  },
  onVideoPlay(e) {
    const index = e.currentTarget.dataset.index;
    const videoId = `video${index}`;
    const videoContext = wx.createVideoContext(videoId, this);
    videoContext.requestFullScreen({ direction: 90 });
  },
  onVideoError(e) {
    const index = e.currentTarget.dataset.index;
    console.error('视频加载错误:', index, e.detail);
    wx.showToast({
      title: '视频加载失败',
      icon: 'none'
    });
  }
});