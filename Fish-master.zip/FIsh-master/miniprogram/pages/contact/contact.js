Page({
  data: {
    contactInfo: {
      phone: '88888888888',
      email: 'fishlantern@qq.com',
      wechat: 'fishlantern_official'
    }
  },
});
