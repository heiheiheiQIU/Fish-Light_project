Page({
  data: {
    steps: [
      { title: '选材准备', desc: '准备制作鱼灯所需的材料。' },
      { title: '骨架制作', desc: '用竹篾等材料搭建鱼灯骨架。' },
      { title: '装饰彩绘', desc: '为鱼灯骨架进行彩绘和装饰。' },
      { title: '成品组装', desc: '将各部分组装成完整鱼灯。' }
    ],
    activeStep: 0,
  },
  onStepTap(e) {
    const idx = e.currentTarget.dataset.index;
    this.setData({ activeStep: idx });
  },
});